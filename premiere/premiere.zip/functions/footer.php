
</main>

<footer class='site-nav center_text'>
<p>©<?php echo (" ".date('Y'));?> - Premiere Conventions Ltd.</p>
</footer>

<script src="js/jquery.min.js"></script>
<script src="js/site.js"></script>
</body>
</html>